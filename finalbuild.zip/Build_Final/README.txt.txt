THE PURRFECT ESCAPE - Version 1.0
By Angel Alvarez, Sofie Ayala, Sanjay Ganeshan, Joanna Gerr, Jason Lam, Femi Oladipupo, Kevin Yang

Known bugs:
-Laser pointer rendering has variable width (thicker or thinner) in some configurations
-Some colliders are slightly too big, causing player characters to get caught on a corner until position adjusted slightly in the opposite direction
-Cat can pass items through some walls if positioned well; the Zone of Collision will register being within proximity to the player character, without taking into account obstacles in between
-If you select the yarn, and then select another inventory item, the yarn gets thrown because it sees you clicked, even though you clicked on the inventory screen 